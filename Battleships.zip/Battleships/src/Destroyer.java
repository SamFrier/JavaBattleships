public class Destroyer extends Ship {
	
	private static final int LENGTH = 4;
	private static final String DESCRIPTION = "Destroyer";

	public Destroyer() {
		super(LENGTH, DESCRIPTION);
	}

}
