public class Battleship extends Ship {

	private static final int LENGTH = 3;
	private static final String DESCRIPTION = "Battleship";

	public Battleship() {
		super(LENGTH, DESCRIPTION);
	}
}
