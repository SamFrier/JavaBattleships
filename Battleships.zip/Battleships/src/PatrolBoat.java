public class PatrolBoat extends Ship {

	private static final int LENGTH = 2;
	private static final String DESCRIPTION = "Patrol Boat";

	public PatrolBoat() {
		super(LENGTH, DESCRIPTION);
	}
}
