public class Carrier extends Ship {

	private static final int LENGTH = 5;
	private static final String DESCRIPTION = "Carrier";

	public Carrier() {
		super(LENGTH, DESCRIPTION);
	}

}
