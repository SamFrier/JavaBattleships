public class Submarine extends Ship {
	
	private static final int LENGTH = 3;
	private static final String DESCRIPTION = "Submarine";

	public Submarine() {
		super(LENGTH, DESCRIPTION);
	}

}
